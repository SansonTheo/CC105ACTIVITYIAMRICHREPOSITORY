package com.group1.i_am_rich

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
